#!/usr/bin/env python3
"""
Verify downloaded episodes/chapters: ensure files exist, redownload if missing,
and prune entries that cannot be recovered.

Runs after MyAutoLibrarianGet.
"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import MyAutoLibrarianGet as mag  # Reuse downloader helpers


KNOWN_EXTS = {".mp3", ".m4a", ".aac", ".wav", ".flac", ".ogg", ".oga", ".opus", ".html", ".htm"}


def load_json(path: Path) -> List[Dict]:
    if not path.exists():
        return []
    try:
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                return data
    except Exception as exc:  # noqa: BLE001
        print(f"  Warning: could not read {path}: {exc}")
    return []


def save_json(path: Path, data: List[Dict]) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except Exception as exc:  # noqa: BLE001
        print(f"  Failed to write {path}: {exc}")


def _search_by_stem(root: Path, title: str) -> Optional[Path]:
    stem = mag.safe_filename(title)
    if not root.exists():
        return None
    for cand in root.rglob("*"):
        if cand.is_file() and cand.suffix.lower() in KNOWN_EXTS:
            if cand.stem.startswith(stem):
                return cand
    return None


def _candidate_paths_podcast(feed_dir: Path, ep: Dict) -> Tuple[List[Path], Path]:
    base = feed_dir
    candidates: List[Path] = []
    rel = ep.get("local_file")
    if rel:
        try:
            rel_path = Path(rel)
            candidates.append(base / rel_path)
            candidates.append(base / "audio" / rel_path.name)
            candidates.append(base / rel_path.name)
        except Exception:
            pass
    filename = mag.build_filename(
        ep.get("title", "episode"),
        ep.get("episode_number"),
        ep.get("url"),
        is_audio=ep.get("enclosure_is_audio"),
        type_hint=ep.get("enclosure_type"),
    )
    candidates.append(base / filename)
    candidates.append(base / "audio" / filename)
    if ep.get("url"):
        name_part = Path(ep.get("url")).name
        candidates.append(base / name_part)
        candidates.append(base / "audio" / name_part)
    return candidates, base


def _candidate_paths_book(feed_dir: Path, ep: Dict, book_hint: Optional[str]) -> Tuple[List[Path], Path]:
    book_folder = book_hint or ep.get("book") or mag.derive_book_folder_from_text(ep.get("title") or "")
    folder = feed_dir / book_folder
    candidates: List[Path] = []
    rel = ep.get("local_file")
    if rel:
        try:
            rel_path = Path(rel)
            if rel_path.parts and rel_path.parts[0] == book_folder:
                rel_path = Path(*rel_path.parts[1:])
            candidates.append(folder / rel_path)
            candidates.append(folder / "audio" / rel_path.name)
            candidates.append(folder / rel_path.name)
        except Exception:
            pass
    filename = mag.build_filename(
        ep.get("title", "chapter"),
        ep.get("episode_number"),
        ep.get("url"),
        pad=True,
        is_audio=ep.get("enclosure_is_audio"),
        type_hint=ep.get("enclosure_type"),
    )
    candidates.append(folder / filename)
    candidates.append(folder / "audio" / filename)
    if ep.get("url"):
        name_part = Path(ep.get("url")).name
        candidates.append(folder / name_part)
        candidates.append(folder / "audio" / name_part)
    return candidates, folder


def _resolve_path(tag: str, feed_dir: Path, ep: Dict, book_hint: Optional[str]) -> Tuple[Optional[Path], Optional[Path]]:
    if tag == "book":
        candidates, folder = _candidate_paths_book(feed_dir, ep, book_hint)
    else:
        candidates, folder = _candidate_paths_podcast(feed_dir, ep)
    for cand in candidates:
        if cand.is_file():
            return cand, folder
    # Fallback: search by stem/title
    found = _search_by_stem(folder, ep.get("title", ""))
    if found:
        return found, folder
    return None, folder


def _download_missing(ep: Dict, dest: Path) -> bool:
    url = ep.get("url") or ep.get("enclosure_url")
    if not url:
        return False
    dest.parent.mkdir(parents=True, exist_ok=True)
    print(f"    Downloading missing file -> {dest.name}")
    ok = mag.download_file(url, str(dest))
    if ok:
        ep["downloaded"] = datetime.now(timezone.utc).isoformat()
    return ok


def _normalize_rel(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root)).replace("\\", "/")
    except Exception:
        return path.name


def _file_mtime_iso(path: Path) -> str:
    try:
        return datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc).isoformat()
    except Exception:
        return datetime.now(timezone.utc).isoformat()


def verify_episode(ep: Dict, tag: str, feed_dir: Path, book_hint: Optional[str]) -> Tuple[Optional[Dict], bool]:
    existing, base_folder = _resolve_path(tag, feed_dir, ep, book_hint)
    if existing:
        # Update metadata with resolved relative path/book.
        if tag == "book":
            ep["book"] = book_hint or ep.get("book") or mag.derive_book_folder_from_text(ep.get("title") or "")
        ep["local_file"] = _normalize_rel(existing, base_folder)
        added_downloaded = False
        if not ep.get("downloaded"):
            ep["downloaded"] = _file_mtime_iso(existing)
            added_downloaded = True
        return ep, added_downloaded

    # Attempt redownload
    candidates, base_folder = (_candidate_paths_book(feed_dir, ep, book_hint) if tag == "book" else _candidate_paths_podcast(feed_dir, ep))
    dest = None
    for cand in candidates:
        dest = cand
        if not cand.exists():
            break
    if dest is None:
        dest = base_folder / (Path(ep.get("url") or ep.get("title") or "missing").name)
    added_downloaded = False
    if _download_missing(ep, dest):
        if tag == "book":
            ep["book"] = book_hint or ep.get("book") or mag.derive_book_folder_from_text(ep.get("title") or "")
        ep["local_file"] = _normalize_rel(dest, base_folder)
        added_downloaded = True
        return ep, added_downloaded

    # Could not recover; drop entry.
    print(f"    Removing entry (file missing, download failed): {ep.get('title')}")
    return None, False


def verify_episodes_file(path: Path, tag: str, feed_name: str, book_hint: Optional[str]) -> Tuple[int, int, int, int]:
    episodes = load_json(path)
    if not episodes:
        return 0, 0, 0, 0
    feed_dir = Path(mag.BOOK_FOLDER if tag == "book" else mag.PODCAST_FOLDER) / mag.safe_filename(feed_name)
    kept: List[Dict] = []
    redownloaded = 0
    removed = 0
    stamped = 0
    for ep in episodes:
        if not isinstance(ep, dict):
            continue
        before = ep.copy()
        result, added_downloaded = verify_episode(ep, tag, feed_dir, book_hint)
        if result:
            if added_downloaded:
                stamped += 1
            if not (before.get("downloaded") == result.get("downloaded")) and result.get("downloaded") and not added_downloaded:
                redownloaded += 1
            kept.append(result)
        else:
            removed += 1
    if kept != episodes:
        print(f"  Updating {path}")
        save_json(path, kept)
    return len(episodes), redownloaded, removed, stamped


def verify_feed(feed: Dict) -> Tuple[int, int, int]:
    name = feed.get("name") or "Unknown"
    tag = (feed.get("tag") or "").lower()
    if tag not in {"podcast", "book"}:
        return (0, 0, 0)
    base_dir = Path(mag.PODCAST_FOLDER if tag == "podcast" else mag.BOOK_FOLDER) / mag.safe_filename(name)
    if tag == "podcast":
        ep_paths = [base_dir / mag.EPISODES_FILENAME]
    else:
        ep_paths = list(base_dir.rglob(mag.EPISODES_FILENAME))
    total = downloaded = removed = stamped = 0
    for ep_path in ep_paths:
        if not ep_path.exists():
            continue
        rel_book = None
        try:
            rel = ep_path.parent.relative_to(base_dir)
            rel_book = rel.parts[0] if rel.parts else None
        except Exception:
            rel_book = None
        print(f" Verifying {ep_path}")
        t, d, r, s = verify_episodes_file(ep_path, tag, name, rel_book)
        total += t
        downloaded += d
        removed += r
        stamped += s
    return total, downloaded, removed, stamped


def main(argv: List[str] | None = None) -> int:
    config = mag.load_config()
    if not config or "feeds" not in config or not isinstance(config["feeds"], list):
        print("No feeds found in config.yaml.", file=sys.stderr)
        return 1

    total = downloaded = removed = stamped = 0
    for feed in config["feeds"]:
        if not isinstance(feed, dict):
            continue
        print(f"\nChecking feed: {feed.get('name')}")
        t, d, r, s = verify_feed(feed)
        total += t
        downloaded += d
        removed += r
        stamped += s

    print(f"\nVerify summary: {total} entries checked, {downloaded} redownloaded, {removed} removed, {stamped} marked as downloaded.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
