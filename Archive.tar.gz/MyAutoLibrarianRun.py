#!/usr/bin/env python3
"""
MyAutoLibrarianRun.py

GUI player for a locally stored audio library produced by MyAutoLibrarianGet.py.
Features:
- Browse/play podcasts and books
- Resume playback with position tracking
- Timed listening sessions
- Random podcast mode (respecting random_enabled.json)
- GUI config.yaml editor
- Clean up trigger via MyAutoLibrarianDel.py

This script does NOT download or delete audio files directly.
"""

from __future__ import annotations

import json
import random
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import tkinter as tk
from tkinter import messagebox, ttk

CONFIG_FILE = "config.yaml"
RANDOM_FILE = "random_enabled.json"
RUN_STATE_FILE = "run_state.json"
UI_STATE_FILE = "ui_state.json"

PODCASTS_DIR = Path("podcasts")
BOOKS_DIR = Path("books")

EPISODES_FILENAME = "episodes.json"


# ---- Helpers -----------------------------------------------------------------
def safe_filename(name: str) -> str:
    import re

    # Strip characters that are unsafe on most filesystems and normalize whitespace.
    cleaned = re.sub(r'[\\/*?:"<>|]', "", name)
    cleaned = re.sub(r"\s+", "_", cleaned).strip("._ ")
    return cleaned or "untitled"


def utc_now_iso() -> str:
    # Produce an ISO8601 timestamp in UTC for metadata fields.
    return datetime.now(timezone.utc).isoformat()


def fmt_short(ts: Optional[str]) -> str:
    # Human-readable timestamp for the UI labels; falls back to raw text.
    if not ts:
        return ""
    try:
        dt = datetime.fromisoformat(ts)
        return dt.strftime("%Y-%m-%d %H:%M")
    except Exception:
        return ts


def ensure_dir(path: Path) -> None:
    # Make sure the target directory exists before writing files.
    path.mkdir(parents=True, exist_ok=True)


def load_json(path: Path, default):
    # Read JSON from disk; return default on any failure.
    if not path.exists():
        return default
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def save_json(path: Path, data) -> None:
    # Write JSON with indentation; show a message box on failure because this runs in GUI.
    try:
        with path.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except Exception as exc:  # noqa: BLE001
        messagebox.showerror("Error", f"Failed to write {path}: {exc}")


def parse_float(val: Optional[float]) -> float:
    # Coerce values to float for positions/speeds; fall back to zero.
    try:
        return float(val)
    except Exception:
        return 0.0


# ---- Audio Playback (VLC if available) ---------------------------------------
class AudioPlayer:
    """Thin wrapper around python-vlc. Falls back to no-op if VLC not available."""

    def __init__(self):
        try:
            import vlc

            self.vlc = vlc
            self.instance = vlc.Instance()  # VLC handle for creating players/media.
            self.player = self.instance.media_player_new()  # Single player reused for all files.
            self.available = True  # Toggle when VLC bindings/import succeed.
        except Exception:
            self.vlc = None
            self.instance = None
            self.player = None
            self.available = False
        self.current_path: Optional[Path] = None
        self.timer_end: Optional[float] = None
        self._timer_thread: Optional[threading.Thread] = None
        self._timer_stop = threading.Event()  # Flag to cancel the sleep timer.
        self._on_end = None
        self._end_hooked = False  # Ensure we only attach the end callback once.

    def load(self, path: Path) -> bool:
        # Prepare a media object for playback; return False if anything is missing.
        if not self.available:
            messagebox.showerror("Audio", "VLC bindings not available. Install python-vlc.")
            return False
        if not path.exists():
            messagebox.showerror("Audio", f"File not found: {path}")
            return False
        media = self.instance.media_new(str(path))
        self.player.set_media(media)
        self.current_path = path
        return True

    def play(self):
        if self.available and self.player:
            self.player.play()

    def pause(self):
        # Pause toggles; VLC keeps position for later resume.
        if self.available and self.player:
            self.player.pause()

    def stop(self):
        # Hard stop the player and clear any active timer.
        if self.available and self.player:
            self.player.stop()
        self._stop_timer()

    def set_position(self, seconds: float):
        if self.available and self.player:
            length = self.player.get_length() / 1000.0
            if length > 0:
                self.player.set_time(int(seconds * 1000))

    def get_position(self) -> float:
        if self.available and self.player:
            return max(0.0, self.player.get_time() / 1000.0)
        return 0.0

    def get_length(self) -> float:
        if self.available and self.player:
            return max(0.0, self.player.get_length() / 1000.0)
        return 0.0

    def start_timer(self, minutes: float, on_timeout):
        # Start/replace a sleep timer that will call on_timeout when it elapses.
        self._stop_timer()
        if minutes <= 0:
            return
        self.timer_end = time.time() + minutes * 60
        self._timer_stop.clear()

        def _run():
            while not self._timer_stop.is_set():
                if time.time() >= self.timer_end:
                    on_timeout()
                    break
                time.sleep(0.5)

        self._timer_thread = threading.Thread(target=_run, daemon=True)
        self._timer_thread.start()

    def _stop_timer(self):
        self._timer_stop.set()
        self.timer_end = None

    def set_on_end(self, callback):
        # Register a callback for when playback finishes.
        self._on_end = callback
        if not self.available or not self.player or not self.vlc or self._end_hooked:
            return
        try:
            manager = self.player.event_manager()
            manager.event_attach(self.vlc.EventType.MediaPlayerEndReached, self._handle_end_event)
            self._end_hooked = True
        except Exception:
            pass

    def _handle_end_event(self, event):  # noqa: ARG002
        if self._on_end:
            try:
                self._on_end()
            except Exception:
                pass


# ---- Data structures ---------------------------------------------------------
@dataclass
class Episode:
    title: str
    published: str
    enclosure_url: str
    local_file: str
    tag: str
    data: Dict = field(default_factory=dict)
    feed_name: str = ""
    book_name: str = ""
    episode_number: Optional[int] = None

    @property
    def completed(self) -> bool:
        # True when the stored metadata marks this item as finished.
        return bool(self.data.get("completed"))

    @property
    def last_pos(self) -> float:
        # Last saved playback position in seconds (0.0 when untouched).
        return parse_float(self.data.get("last_position_seconds"))


# ---- Library loading ---------------------------------------------------------
def load_config():
    import yaml  # type: ignore

    # Load config.yaml (feeds list); default to empty when missing.
    if not Path(CONFIG_FILE).exists():
        return {"feeds": []}
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {"feeds": []}


def save_config(config) -> None:
    import yaml  # type: ignore

    # Persist config.yaml with stable key ordering.
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        yaml.safe_dump(config, f, sort_keys=False)


def load_random_enabled(feeds) -> Dict[str, bool]:
    # Ensure every podcast feed has a toggle entry; default to enabled.
    data = load_json(Path(RANDOM_FILE), {})
    if not isinstance(data, dict):
        data = {}
    for feed in feeds:
        if feed.get("tag") == "podcast" and feed.get("name") not in data:
            data[feed.get("name")] = True
    return data


def save_random_enabled(data: Dict[str, bool]) -> None:
    save_json(Path(RANDOM_FILE), data)


def _normalize_meta_key(value: str) -> str:
    return str(value).replace("\\", "/").strip().lower()


def _build_book_metadata_lookup(feed_name: str) -> Dict[str, Dict]:
    """Load any episodes.json under a book feed (root and nested) for metadata lookup."""
    feed_folder = BOOKS_DIR / safe_filename(feed_name)
    lookup: Dict[str, Dict] = {}
    json_paths = [feed_folder / EPISODES_FILENAME]
    json_paths.extend(feed_folder.rglob(EPISODES_FILENAME))
    seen = set()
    for path in json_paths:
        if path in seen or not path.is_file():
            continue
        seen.add(path)
        raw = load_json(path, [])
        if not isinstance(raw, list):
            continue
        for entry in raw:
            if not isinstance(entry, dict):
                continue
            local_file = entry.get("local_file") or entry.get("filename") or entry.get("path") or ""
            book = entry.get("book") or entry.get("book_name") or ""
            candidates = []
            if local_file:
                candidates.append(_normalize_meta_key(local_file))
                candidates.append(_normalize_meta_key(Path(local_file).name))
                if book:
                    pref = safe_filename(book)
                    candidates.append(_normalize_meta_key(f"{pref}/{local_file}"))
                    candidates.append(_normalize_meta_key(f"{pref}/{Path(local_file).name}"))
            url = entry.get("enclosure_url") or entry.get("url") or ""
            if url:
                candidates.append(_normalize_meta_key(url))
            for key in candidates:
                if key and key not in lookup:
                    lookup[key] = entry
    return lookup


def _match_book_metadata(ep: Episode, lookup: Dict[str, Dict]) -> Optional[Dict]:
    if not lookup:
        return None
    candidates = []
    if ep.local_file:
        candidates.append(_normalize_meta_key(ep.local_file))
        candidates.append(_normalize_meta_key(Path(ep.local_file).name))
        if ep.book_name:
            pref = safe_filename(ep.book_name)
            candidates.append(_normalize_meta_key(f"{pref}/{ep.local_file}"))
            candidates.append(_normalize_meta_key(f"{pref}/{Path(ep.local_file).name}"))
    if ep.enclosure_url:
        candidates.append(_normalize_meta_key(ep.enclosure_url))
    for key in candidates:
        if key in lookup:
            return lookup[key]
    return None


def load_episodes_for_feed(feed: Dict) -> List[Episode]:
    # Prefer persisted metadata; fall back to disk discovery when missing.
    name = feed.get("name") or ""
    tag = feed.get("tag") or ""
    base_dir = PODCASTS_DIR if tag == "podcast" else BOOKS_DIR
    folder = base_dir / safe_filename(name)
    ep_path = folder / EPISODES_FILENAME
    raw_eps = load_json(ep_path, [])  # episodes.json contents for this feed.
    episodes: List[Episode] = []
    if isinstance(raw_eps, list):
        for ep in raw_eps:
            if not isinstance(ep, dict):
                continue
            episodes.append(
                Episode(
                    title=ep.get("title", "Unknown"),
                    published=ep.get("published") or ep.get("pubDate") or "",
                    enclosure_url=ep.get("enclosure_url") or ep.get("url") or "",
                    local_file=ep.get("local_file") or ep.get("filename") or ep.get("path") or "",
                    tag=ep.get("tag") or tag,
                    data=ep.get("data") or {},
                    feed_name=name,
                    book_name=ep.get("book") or feed.get("name") or "",
                    episode_number=ep.get("episode_number"),
                )
            )
    # For books, prefer on-disk discovery to align with foldered chapters.
    if tag == "book":
        disk_eps = discover_audio_from_disk(feed)
        if disk_eps:
            meta_lookup = _build_book_metadata_lookup(name)
            for ep in disk_eps:
                meta = _match_book_metadata(ep, meta_lookup)
                if meta:
                    ep.data = meta.get("data") or {}
                    ep.enclosure_url = meta.get("enclosure_url") or meta.get("url") or ep.enclosure_url
                    ep.published = meta.get("published") or meta.get("pubDate") or ep.published
                    ep.episode_number = meta.get("episode_number")
            return disk_eps
    if episodes:
        return episodes

    # Fallback: discover audio files on disk when episodes.json is missing/empty.
    return discover_audio_from_disk(feed)


def discover_audio_from_disk(feed: Dict) -> List[Episode]:
    """Conservative fallback: list audio files if metadata is missing."""
    name = feed.get("name") or ""
    tag = feed.get("tag") or ""
    base_dir = PODCASTS_DIR if tag == "podcast" else BOOKS_DIR
    feed_dir = base_dir / safe_filename(name)
    if not feed_dir.exists():
        return []

    audio_exts = {".mp3", ".m4a", ".aac", ".wav", ".flac", ".ogg"}
    found: List[Episode] = []
    for path in feed_dir.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix.lower() not in audio_exts:
            continue
        try:
            rel = path.relative_to(feed_dir)
        except Exception:
            rel = Path(path.name)
        book_name = ""
        if tag == "book":
            # Use immediate subfolder as book name when present.
            parts = rel.parts
            if len(parts) > 1:
                book_name = parts[0]
            else:
                book_name = name
        found.append(
            Episode(
                title=path.stem,
                published="",
                enclosure_url="",
                local_file=str(rel).replace("\\", "/"),
                tag=tag,
                data={},
                feed_name=name,
                book_name=book_name or name,
                episode_number=None,
            )
        )
    return found


def load_library(config) -> Tuple[Dict[str, List[Episode]], Dict[str, List[Episode]]]:
    # Build two maps keyed by feed name: podcasts and books.
    podcasts: Dict[str, List[Episode]] = {}
    books: Dict[str, List[Episode]] = {}
    for feed in config.get("feeds", []):
        tag = feed.get("tag")
        name = feed.get("name") or "Unknown"
        eps = load_episodes_for_feed(feed)
        if tag == "podcast":
            podcasts[name] = eps
        elif tag == "book":
            books[name] = eps
    return podcasts, books


# ---- State persistence -------------------------------------------------------
def load_run_state() -> Dict:
    return load_json(Path(RUN_STATE_FILE), {})


def save_run_state(state: Dict) -> None:
    save_json(Path(RUN_STATE_FILE), state)


def update_episode_metadata(feed_name: str, episode: Episode, data: Dict) -> None:
    # Merge incoming metadata into episodes.json for this feed/item.
    tag = episode.tag
    base_dir = PODCASTS_DIR if tag == "podcast" else BOOKS_DIR
    feed_folder = base_dir / safe_filename(feed_name)
    folder = feed_folder
    if tag == "book" and episode.book_name:
        folder = feed_folder / safe_filename(episode.book_name)
    ep_path = folder / EPISODES_FILENAME
    raw = load_json(ep_path, [])
    changed = False
    for entry in raw:
        if not isinstance(entry, dict):
            continue
        if entry.get("enclosure_url") == episode.enclosure_url or entry.get("url") == episode.enclosure_url:
            existing = entry.get("data") or {}
            if not isinstance(existing, dict):
                existing = {}
            entry["data"] = existing
            entry["data"].update(data)
            # record first_played if missing
            if "first_played" not in entry["data"] and data.get("last_listened_to"):
                entry["data"]["first_played"] = data.get("last_listened_to")
            changed = True
            break
    if not changed:
        try:
            rel_path = None
            if episode.local_file:
                rel_path = episode.local_file
            else:
                rel_path = ""
        except Exception:
            rel_path = ""
        if "first_played" not in data and data.get("last_listened_to"):
            data = {**data, "first_played": data.get("last_listened_to")}
        # Append a new record if needed
        raw.append(
            {
                "title": episode.title,
                "published": episode.published,
                "enclosure_url": episode.enclosure_url,
                "local_file": rel_path,
                "tag": episode.tag,
                "episode_number": episode.episode_number,
                "data": data,
            }
        )
    ensure_dir(folder)
    save_json(ep_path, raw)
    # Keep in-memory state in sync for coloring/resume.
    episode.data.update(data)


# ---- GUI Application ---------------------------------------------------------
class MyAutoLibrarianApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("MyAutoLibrarian Run")
        self.geometry("900x600")

        self.config_data = load_config()
        self.podcasts, self.books = load_library(self.config_data)
        self.random_enabled = load_random_enabled(self.config_data.get("feeds", []))
        self.player = AudioPlayer()
        self._pending_end_event = False
        self.player.set_on_end(self._on_player_end)
        self.current_episode: Optional[Episode] = None
        self.playing_episode: Optional[Episode] = None
        self._length_cache: Dict[str, float] = {}
        self.queue: List[Episode] = []
        self._last_queue_position: Dict[str, float] = {}
        self.book_index: Dict[str, List[Episode]] = {}
        self.timer_remaining_var = tk.StringVar(value="")
        self.ui_state = load_json(Path(UI_STATE_FILE), {})
        self.include_partials_var = tk.BooleanVar(value=False)
        self.speed_var = tk.StringVar(value="1.0")
        self.search_podcast_var = tk.StringVar()
        self.search_book_var = tk.StringVar()
        self.filtered_podcast_episodes: List[Episode] = []
        self.filtered_book_chapters: List[Episode] = []
        self.is_playing = False
        self.resume_position: Optional[float] = None

        self._build_ui()
        self._load_run_state()
        self._refresh_lists()
        self._tick_ui()
        self._load_ui_state()

    # UI construction
    def _build_ui(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("TLabel", padding=2, background="#e6f2ff")  # Light background for labels.
        style.configure("TButton", padding=4)  # Slight padding on buttons.
        style.configure("TLabelframe", padding=6, background="#e6f2ff")
        style.configure("TLabelframe.Label", background="#e6f2ff")
        style.configure("TFrame", background="#e6f2ff")
        style.configure("TNotebook", background="#e6f2ff")
        style.configure("TNotebook.Tab", padding=(8, 4))
        style.configure("TCombobox", fieldbackground="white")

        notebook = ttk.Notebook(self)
        notebook.pack(fill=tk.BOTH, expand=True)

        self.play_frame = ttk.Frame(notebook)  # Playback tab.
        self.settings_frame = ttk.Frame(notebook)  # Settings tab.
        notebook.add(self.play_frame, text="Play")
        notebook.add(self.settings_frame, text="Settings")

        self._build_play_tab()
        self._build_settings_tab()

    def _build_play_tab(self):
        frame = ttk.Frame(self.play_frame, padding=8)
        frame.pack(fill=tk.BOTH, expand=True)

        # Mode selection
        mode_frame = ttk.LabelFrame(frame, text="Mode")
        mode_frame.pack(fill=tk.X, pady=(0, 6))
        self.mode_var = tk.StringVar(value="podcast")
        for val in ("random", "podcast", "book", "queue"):
            ttk.Radiobutton(
                mode_frame,
                text=val.title(),
                value=val,
                variable=self.mode_var,
                command=self._mode_changed,
            ).pack(side=tk.LEFT, padx=5, pady=5)

        # Timer
        timer_frame = ttk.Frame(frame)
        timer_frame.pack(fill=tk.X, pady=(0, 6))
        ttk.Label(timer_frame, text="Play for (minutes):").pack(side=tk.LEFT)
        self.timer_var = tk.StringVar(value="0")
        ttk.Entry(timer_frame, textvariable=self.timer_var, width=8).pack(side=tk.LEFT, padx=4)
        ttk.Label(timer_frame, textvariable=self.timer_remaining_var, foreground="blue").pack(side=tk.LEFT, padx=8)
        ttk.Label(timer_frame, text="Speed").pack(side=tk.LEFT, padx=(12, 2))
        self.speed_box = ttk.Combobox(
            timer_frame,
            textvariable=self.speed_var,
            state="readonly",
            width=6,
            values=["0.8", "1.0", "1.2", "1.5", "2.0"],
        )
        self.speed_box.pack(side=tk.LEFT)
        self.speed_box.bind("<<ComboboxSelected>>", lambda e: self._apply_speed())

        # Selection area
        selection = ttk.Panedwindow(frame, orient=tk.HORIZONTAL)
        selection.pack(fill=tk.BOTH, expand=True, pady=(0, 6))

        # Podcast selection
        podcast_box = ttk.LabelFrame(selection, text="Podcasts", padding=6)
        selection.add(podcast_box, weight=1)
        ttk.Label(podcast_box, text="Feed").pack(anchor="w")
        self.podcast_feed_var = tk.StringVar()
        self.podcast_feed_cb = ttk.Combobox(podcast_box, textvariable=self.podcast_feed_var, state="readonly")
        self.podcast_feed_cb.pack(fill=tk.X, pady=2)
        self.podcast_feed_cb.bind("<<ComboboxSelected>>", lambda e: self._refresh_episode_list())

        search_p_frame = ttk.Frame(podcast_box)
        search_p_frame.pack(fill=tk.X, pady=(4, 2))
        ttk.Label(search_p_frame, text="Filter").pack(side=tk.LEFT)
        ttk.Entry(search_p_frame, textvariable=self.search_podcast_var).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)
        ttk.Button(search_p_frame, text="Clear", command=lambda: self._clear_search("podcast")).pack(side=tk.LEFT)

        ttk.Label(podcast_box, text="Episodes").pack(anchor="w", pady=(6, 0))
        ep_frame = ttk.Frame(podcast_box)
        ep_frame.pack(fill=tk.BOTH, expand=True)
        ep_scroll = ttk.Scrollbar(ep_frame, orient=tk.VERTICAL)
        self.episode_list = tk.Listbox(ep_frame, height=15, yscrollcommand=ep_scroll.set)
        ep_scroll.config(command=self.episode_list.yview)
        self.episode_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        ep_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.episode_list.bind("<<ListboxSelect>>", lambda e: self._select_episode_from_list())

        # Book selection
        book_box = ttk.LabelFrame(selection, text="Books", padding=6)
        selection.add(book_box, weight=1)
        ttk.Label(book_box, text="Book").pack(anchor="w")
        self.book_var = tk.StringVar()
        self.book_cb = ttk.Combobox(book_box, textvariable=self.book_var, state="readonly")
        self.book_cb.pack(fill=tk.X, pady=2)
        self.book_cb.bind("<<ComboboxSelected>>", lambda e: self._refresh_book_chapters())

        search_b_frame = ttk.Frame(book_box)
        search_b_frame.pack(fill=tk.X, pady=(4, 2))
        ttk.Label(search_b_frame, text="Filter").pack(side=tk.LEFT)
        ttk.Entry(search_b_frame, textvariable=self.search_book_var).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)
        ttk.Button(search_b_frame, text="Clear", command=lambda: self._clear_search("book")).pack(side=tk.LEFT)

        ttk.Label(book_box, text="Chapters").pack(anchor="w", pady=(6, 0))
        ch_frame = ttk.Frame(book_box)
        ch_frame.pack(fill=tk.BOTH, expand=True)
        ch_scroll = ttk.Scrollbar(ch_frame, orient=tk.VERTICAL)
        self.chapter_list = tk.Listbox(ch_frame, height=15, yscrollcommand=ch_scroll.set)
        ch_scroll.config(command=self.chapter_list.yview)
        self.chapter_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        ch_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.chapter_list.bind("<<ListboxSelect>>", lambda e: self._select_chapter_from_list())

        # Controls  make for loop for compress of code 
        controls = ttk.Frame(frame)
        controls.pack(fill=tk.X, pady=6)
        self.play_pause_btn = ttk.Button(controls, text="Play", command=self.toggle_play_pause)
        self.play_pause_btn.pack(side=tk.LEFT, padx=4)
        ttk.Button(controls, text="Next Random", command=self.next_random).pack(side=tk.LEFT, padx=4)
        ttk.Button(controls, text="Next Queue", command=self.next_queue).pack(side=tk.LEFT, padx=4)
        ttk.Button(controls, text="Mark Complete", command=self.mark_complete).pack(side=tk.LEFT, padx=4)
        ttk.Checkbutton(controls, text="Random: include partials", variable=self.include_partials_var, command=self._refresh_episode_list).pack(side=tk.LEFT, padx=6)
        ttk.Button(controls, text="Archive", command=self.mark_archive).pack(side=tk.LEFT, padx=4)

        bm_frame = ttk.Frame(frame)
        bm_frame.pack(fill=tk.X, pady=(0, 6))
        ttk.Button(bm_frame, text="Add Bookmark", command=self.add_bookmark).pack(side=tk.LEFT, padx=4)
        ttk.Button(bm_frame, text="Jump to Last Bookmark", command=self.jump_last_bookmark).pack(side=tk.LEFT, padx=4)

        skip_box = ttk.Frame(frame)
        skip_box.pack(fill=tk.X, pady=(0, 6))
        ttk.Label(skip_box, text="Skip seconds (+/-):").pack(side=tk.LEFT)
        self.skip_var = tk.StringVar(value="15")
        ttk.Entry(skip_box, textvariable=self.skip_var, width=6).pack(side=tk.LEFT, padx=4)
        ttk.Button(skip_box, text="-", command=lambda: self.skip_time(-1)).pack(side=tk.LEFT, padx=2)
        ttk.Button(skip_box, text="+", command=lambda: self.skip_time(1)).pack(side=tk.LEFT, padx=2)

        queue_box = ttk.LabelFrame(frame, text="Queue")
        queue_box.pack(fill=tk.BOTH, expand=True, pady=(0, 6))
        q_controls = ttk.Frame(queue_box)
        q_controls.pack(fill=tk.X, pady=2)
        ttk.Button(q_controls, text="Add Selected to Queue", command=self._add_to_queue).pack(side=tk.LEFT, padx=4)
        ttk.Button(q_controls, text="Remove Selected", command=self._remove_from_queue).pack(side=tk.LEFT, padx=4)
        ttk.Button(q_controls, text="Clear Queue", command=self._clear_queue).pack(side=tk.LEFT, padx=4)
        q_frame = ttk.Frame(queue_box)
        q_frame.pack(fill=tk.BOTH, expand=True)
        q_scroll = ttk.Scrollbar(q_frame, orient=tk.VERTICAL)
        self.queue_list = tk.Listbox(q_frame, height=6, yscrollcommand=q_scroll.set)
        q_scroll.config(command=self.queue_list.yview)
        self.queue_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        q_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        # Status
        status = ttk.Frame(frame)
        status.pack(fill=tk.X, pady=(0, 2))
        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(status, textvariable=self.status_var).pack(anchor="w")
        self.progress_var = tk.StringVar(value="")
        ttk.Label(status, textvariable=self.progress_var, foreground="blue").pack(anchor="w")  # Progress info line.

    def _refresh_queue(self):
        self.queue_list.delete(0, tk.END)
        for ep in self.queue:
            label = f"{ep.feed_name}: {ep.title}"
            self.queue_list.insert(tk.END, label)

    def _add_to_queue(self):
        ep = self.current_episode
        if not ep:
            self.status_var.set("Select an episode to add to queue.")
            return
        self.queue.append(ep)
        self.status_var.set(f"Queued: {ep.title}")
        self._refresh_queue()
        self._persist_run_state(self.mode_var.get(), self.current_episode, self.resume_position or ep.last_pos or 0)

    def _remove_from_queue(self):
        sel = self.queue_list.curselection()
        if not sel:
            return
        idx = sel[0]
        if 0 <= idx < len(self.queue):
            removed = self.queue.pop(idx)
            self.status_var.set(f"Removed from queue: {removed.title}")
            self._refresh_queue()
            self._persist_run_state(self.mode_var.get(), self.current_episode, self.resume_position or 0)

    def _clear_queue(self):
        self.queue = []
        self._refresh_queue()
        self._persist_run_state(self.mode_var.get(), self.current_episode, self.resume_position or 0)

    def next_queue(self):
        if self.mode_var.get() != "queue":
            self.status_var.set("Switch to Queue mode to use Next Queue.")
            return
        if self.is_playing:
            self.pause_playback()
        current = self.playing_episode or self.current_episode
        # stash current with its position so it is not lost
        if current and not current.completed:
            pos = self.player.get_position()
            current.data["last_position_seconds"] = pos
            update_episode_metadata(
                current.feed_name,
                current,
                {"last_listened_to": utc_now_iso(), "last_position_seconds": pos, "completed": False},
            )
            if current not in self.queue:
                self.queue.append(current)
        self.player.stop()
        self.playing_episode = None
        self.current_episode = None
        self.resume_position = None
        self._set_play_state(False)
        if not self.queue:
            self.status_var.set("Queue is empty.")
            self._persist_run_state(self.mode_var.get(), None, 0)
            return
        self._refresh_queue()
        self._persist_run_state(self.mode_var.get(), None, 0)
        self.play_selected()

    def _build_settings_tab(self):
        frame = self.settings_frame

        # Config editor
        config_box = ttk.LabelFrame(frame, text="Feeds (config.yaml)")
        config_box.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

        self.feed_tree = ttk.Treeview(config_box, columns=("url", "tag"), show="headings", selectmode="browse")
        self.feed_tree.heading("url", text="URL")
        self.feed_tree.heading("tag", text="Tag")
        self.feed_tree.pack(fill=tk.BOTH, expand=True, pady=4)

        feed_btns = ttk.Frame(config_box)
        feed_btns.pack(fill=tk.X, pady=4)
        ttk.Button(feed_btns, text="Add", command=self._add_feed).pack(side=tk.LEFT, padx=4)
        ttk.Button(feed_btns, text="Edit", command=self._edit_feed).pack(side=tk.LEFT, padx=4)
        ttk.Button(feed_btns, text="Remove", command=self._remove_feed).pack(side=tk.LEFT, padx=4)
        ttk.Button(feed_btns, text="Save config.yaml", command=self._save_config).pack(side=tk.LEFT, padx=4)

        # Random toggles
        random_box = ttk.LabelFrame(frame, text="Random Feed Inclusion (podcasts)")
        random_box.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
        self.random_list = tk.Listbox(random_box, selectmode=tk.MULTIPLE, height=8)
        self.random_list.pack(fill=tk.BOTH, expand=True, pady=4)
        ttk.Button(random_box, text="Toggle Selected", command=self._toggle_random_selection).pack(pady=4)

        # Clean up (tk.X?) chatgpt code remove this dose not use the del class that is needed
        cleanup_box = ttk.LabelFrame(frame, text="Maintenance")
        cleanup_box.pack(fill=tk.X, padx=8, pady=8)
        ttk.Button(cleanup_box, text="Clean up", command=self._run_cleanup).pack(side=tk.LEFT, padx=4, pady=4)
        self.cleanup_output = tk.Text(cleanup_box, height=6)
        self.cleanup_output.pack(fill=tk.BOTH, expand=True, pady=4)

    # --- UI helpers -----------------------------------------------------------
    def _refresh_lists(self):
        # Rebuild all dropdowns/lists from the current config/library data.
        # Podcasts
        feeds = [name for name in self.podcasts.keys()]
        self.podcast_feed_cb["values"] = feeds
        if feeds and not self.podcast_feed_var.get():
            self.podcast_feed_var.set(feeds[0])
        self._refresh_episode_list()

        # Books
        book_map: Dict[str, List[Episode]] = {}
        for feed_name, eps in self.books.items():
            for ep in eps:
                title = ep.book_name or feed_name
                book_map.setdefault(title, []).append(ep)
        self.book_index = book_map
        book_names = sorted(book_map.keys())
        self.book_cb["values"] = book_names
        if book_names and not self.book_var.get():
            self.book_var.set(book_names[0])
        self._refresh_book_chapters()

        # Feed tree
        for row in self.feed_tree.get_children():
            self.feed_tree.delete(row)
        for feed in self.config_data.get("feeds", []):
            self.feed_tree.insert("", "end", iid=feed.get("name"), values=(feed.get("url"), feed.get("tag")))

        # Random list
        self.random_list.delete(0, tk.END)
        for feed in self.config_data.get("feeds", []):
            if feed.get("tag") != "podcast":
                continue
            name = feed.get("name")
            enabled = self.random_enabled.get(name, True)
            label = f"[{'X' if enabled else ' '}] {name}"
            self.random_list.insert(tk.END, label)

    def _refresh_episode_list(self):
        self.episode_list.delete(0, tk.END)
        feed_name = self.podcast_feed_var.get()
        episodes = list(self.podcasts.get(feed_name, []))
        filter_text = (self.search_podcast_var.get() or "").lower().strip()
        if filter_text:
            episodes = [e for e in episodes if filter_text in e.title.lower()]
        self.filtered_podcast_episodes = episodes
        selected_idx = None
        if self.current_episode and self.current_episode in episodes:
            selected_idx = episodes.index(self.current_episode)
        for ep in episodes:
            color = "black"
            if ep.data.get("archived"):
                color = "gray"
            if ep.completed:
                color = "red"
            elif ep.last_pos > 0:
                color = "yellow"
            # Color-code list entries based on completion/archived/partial state.
            self.episode_list.insert(tk.END, ep.title)
            idx_after = self.episode_list.size() - 1
            if 0 <= idx_after < self.episode_list.size():
                try:
                    self.episode_list.itemconfig(idx_after, fg=color)
                except Exception:
                    pass
        if selected_idx is not None:
            self.episode_list.selection_set(selected_idx)
            self.episode_list.see(selected_idx)
# there this Delete but its not useing the right Library i need to be one line here i will be looking a blame later 
    def _refresh_book_chapters(self):
        self.chapter_list.delete(0, tk.END)
        book_name = self.book_var.get()
        episodes = list(self.book_index.get(book_name, []))
        filter_text = (self.search_book_var.get() or "").lower().strip()
        if filter_text:
            episodes = [e for e in episodes if filter_text in e.title.lower()]
        self.filtered_book_chapters = episodes
        selected_idx = None
        if self.current_episode and self.current_episode in episodes:
            selected_idx = episodes.index(self.current_episode)
        for ep in episodes:
            color = "black"
            if ep.data.get("archived"):
                color = "gray"
            if ep.completed:
                color = "red"
            elif ep.last_pos > 0:
                color = "yellow"
            # Color-code list entries based on completion/archived/partial state.
            self.chapter_list.insert(tk.END, ep.title)
            idx_after = self.chapter_list.size() - 1
            if 0 <= idx_after < self.chapter_list.size():
                try:
                    self.chapter_list.itemconfig(idx_after, fg=color)
                except Exception:
                    pass
        if selected_idx is not None:
            self.chapter_list.selection_set(selected_idx)
            self.chapter_list.see(selected_idx)

    def _select_episode_from_list(self):
        feed_name = self.podcast_feed_var.get()
        episodes = self.filtered_podcast_episodes or list(self.podcasts.get(feed_name, []))
        sel = self.episode_list.curselection()
        if not sel:
            return
        idx = sel[0]
        if idx < len(episodes):
            self.current_episode = episodes[idx]
            # Cache stored progress so hitting Play resumes from where you left off.
            self.resume_position = episodes[idx].last_pos

    def _select_chapter_from_list(self):
        book_name = self.book_var.get()
        episodes = self.filtered_book_chapters or list(self.book_index.get(book_name, []))
        sel = self.chapter_list.curselection()
        if not sel:
            return
        idx = sel[0]
        if idx < len(episodes):
            self.current_episode = episodes[idx]
            # Cache stored progress so hitting Play resumes from where you left off.
            self.resume_position = episodes[idx].last_pos

    def _mode_changed(self):
        # Flip UI controls based on mode and reset partials filter.
        mode = self.mode_var.get()
        if mode == "random":
            self.book_cb.configure(state="disabled")
            self.chapter_list.configure(state="disabled")
        elif mode == "podcast":
            self.book_cb.configure(state="readonly")
            self.chapter_list.configure(state="normal")
        elif mode == "book":
            self.book_cb.configure(state="readonly")
            self.chapter_list.configure(state="normal")
        elif mode == "queue":
            self.book_cb.configure(state="readonly")
            self.chapter_list.configure(state="normal")
        self.status_var.set(f"Mode: {mode}")
        self.include_partials_var.set(False)
        self._refresh_episode_list()

    def _clear_search(self, which: str):
        # Clear the appropriate search box and refresh lists.
        if which == "podcast":
            self.search_podcast_var.set("")
            self._refresh_episode_list()
        elif which == "book":
            self.search_book_var.set("")
            self._refresh_book_chapters()

    # --- Playback -------------------------------------------------------------
    def _resolve_episode_path(self, ep: Episode) -> Optional[Path]:
        rel = ep.local_file or ""
        base_dir = PODCASTS_DIR if ep.tag == "podcast" else BOOKS_DIR
        feed_folder = base_dir / safe_filename(ep.feed_name)
        folder = feed_folder
        if ep.tag == "book" and ep.book_name:
            folder = feed_folder / safe_filename(ep.book_name)
        path = folder / rel
        # Exact relative match (ideal case).
        if path.is_file():
            if not ep.local_file:
                try:
                    ep.local_file = str(path.relative_to(folder)).replace("\\", "/")
                except Exception:
                    ep.local_file = str(path.name)
            return path
        # Try audio/ subfolder
        alt = folder / "audio" / Path(rel).name
        if alt.is_file():
            return alt
        # Try one deeper: feed/book/audio/<file>
        if ep.tag == "book":
            alt_book_audio = feed_folder / safe_filename(ep.book_name or "") / "audio" / Path(rel).name
            if alt_book_audio.is_file():
                return alt_book_audio
        # Try directly under folder
        alt2 = folder / Path(rel).name
        if alt2.is_file():
            return alt2
        # Try basename of enclosure URL
        base_name = Path(ep.enclosure_url).name if ep.enclosure_url else ""
        if base_name:
            for candidate in [folder / base_name, folder / "audio" / base_name]:
                if candidate.is_file():
                    ep.local_file = str(candidate.relative_to(folder)).replace("\\", "/")
                    return candidate
            if ep.tag == "book":
                candidate = feed_folder / safe_filename(ep.book_name or "") / "audio" / base_name
                if candidate.is_file():
                    ep.local_file = str(candidate.relative_to(folder)).replace("\\", "/")
                    return candidate
        audio_exts = {".mp3", ".m4a", ".aac", ".wav", ".flac", ".ogg"}
        # Try episode number prefix patterns
        if ep.episode_number is not None:
            num_str = str(ep.episode_number)
            num_zero = num_str.zfill(2)
            for candidate in folder.rglob("*"):
                if not candidate.is_file() or candidate.suffix.lower() not in audio_exts:
                    continue
                stem = candidate.stem
                if stem.startswith(num_str + "-") or stem.startswith(num_zero + "-") or stem.startswith(num_str + "_"):
                    try:
                        ep.local_file = str(candidate.relative_to(folder)).replace("\\", "/")
                    except Exception:
                        ep.local_file = candidate.name
                    return candidate
        # Try matching on sanitized title prefix
        base_title = safe_filename(ep.title)
        for candidate in folder.rglob("*"):
            if not candidate.is_file() or candidate.suffix.lower() not in audio_exts:
                continue
            if candidate.stem.startswith(base_title):
                try:
                    ep.local_file = str(candidate.relative_to(folder)).replace("\\", "/")
                except Exception:
                    ep.local_file = candidate.name
                return candidate
        # Final fallback: search any audio under feed/book/audio
        if ep.tag == "book":
            for candidate in (feed_folder / safe_filename(ep.book_name or "") / "audio").rglob("*"):
                if candidate.is_file() and candidate.suffix.lower() in audio_exts:
                    ep.local_file = str(candidate.relative_to(folder)).replace("\\", "/")
                    return candidate
        return None

    def _episode_lookup_keys(self, ep: Episode) -> List[str]:
        keys: List[str] = []
        if ep.enclosure_url:
            keys.append(_normalize_meta_key(ep.enclosure_url))
        if ep.local_file:
            keys.append(_normalize_meta_key(ep.local_file))
            keys.append(_normalize_meta_key(Path(ep.local_file).name))
        if ep.book_name:
            pref = safe_filename(ep.book_name)
            if ep.local_file:
                keys.append(_normalize_meta_key(f"{pref}/{ep.local_file}"))
                keys.append(_normalize_meta_key(f"{pref}/{Path(ep.local_file).name}"))
        return [k for k in keys if k]

    def _episode_cache_key(self, ep: Episode) -> str:
        keys = self._episode_lookup_keys(ep)
        if keys:
            return keys[0]
        return f"{ep.feed_name}:{ep.title}"

    def _episode_identifier(self, ep: Episode) -> str:
        return (
            _normalize_meta_key(ep.enclosure_url)
            or _normalize_meta_key(ep.local_file)
            or _normalize_meta_key(ep.title)
        )

    def _episode_entry_keys(self, entry: Dict) -> List[str]:
        keys: List[str] = []
        book = entry.get("book") or entry.get("book_name")
        pref = safe_filename(book) if book else ""
        for field in ("enclosure_url", "url", "local_file", "filename", "path"):
            val = entry.get(field)
            if not val:
                continue
            keys.append(_normalize_meta_key(val))
            try:
                keys.append(_normalize_meta_key(Path(val).name))
            except Exception:
                pass
            if pref:
                keys.append(_normalize_meta_key(f"{pref}/{val}"))
                try:
                    keys.append(_normalize_meta_key(f"{pref}/{Path(val).name}"))
                except Exception:
                    pass
        return [k for k in keys if k]

    def _saved_position_from_disk(self, ep: Episode) -> float:
        if not ep:
            return 0.0
        candidate_paths = []
        if ep.tag == "book":
            base = BOOKS_DIR / safe_filename(ep.feed_name)
            if ep.book_name:
                candidate_paths.append(base / safe_filename(ep.book_name) / EPISODES_FILENAME)
            candidate_paths.append(base / EPISODES_FILENAME)
        else:
            base = PODCASTS_DIR / safe_filename(ep.feed_name)
            candidate_paths.append(base / EPISODES_FILENAME)
        lookup_keys = set(self._episode_lookup_keys(ep))
        for path in candidate_paths:
            raw = load_json(path, [])
            if not isinstance(raw, list):
                continue
            for entry in raw:
                if not isinstance(entry, dict):
                    continue
                entry_keys = set(self._episode_entry_keys(entry))
                if lookup_keys.intersection(entry_keys):
                    data = entry.get("data") or {}
                    pos = data.get("last_position_seconds")
                    if pos is None:
                        pos = entry.get("last_position_seconds")
                    return parse_float(pos)
        return 0.0

    def _saved_length_from_disk(self, ep: Episode) -> float:
        if not ep:
            return 0.0
        candidate_paths = []
        if ep.tag == "book":
            base = BOOKS_DIR / safe_filename(ep.feed_name)
            if ep.book_name:
                candidate_paths.append(base / safe_filename(ep.book_name) / EPISODES_FILENAME)
            candidate_paths.append(base / EPISODES_FILENAME)
        else:
            base = PODCASTS_DIR / safe_filename(ep.feed_name)
            candidate_paths.append(base / EPISODES_FILENAME)
        lookup_keys = set(self._episode_lookup_keys(ep))
        for path in candidate_paths:
            raw = load_json(path, [])
            if not isinstance(raw, list):
                continue
            for entry in raw:
                if not isinstance(entry, dict):
                    continue
                entry_keys = set(self._episode_entry_keys(entry))
                if lookup_keys.intersection(entry_keys):
                    data = entry.get("data") or {}
                    length = data.get("length_seconds")
                    if length is None:
                        length = entry.get("length_seconds")
                    return parse_float(length)
        return 0.0

    def _get_length_seconds(self, ep: Optional[Episode], runtime_length_seconds: float) -> float:
        if not ep:
            return max(0.0, runtime_length_seconds)
        key = self._episode_cache_key(ep)
        cached = self._length_cache.get(key, 0.0)
        if cached > 0:
            return cached
        saved = parse_float((ep.data or {}).get("length_seconds"))
        if saved > 0:
            self._length_cache[key] = saved
            return saved
        disk = self._saved_length_from_disk(ep)
        if disk > 0:
            ep.data["length_seconds"] = disk
            self._length_cache[key] = disk
            return disk
        runtime = max(0.0, runtime_length_seconds)
        if runtime > 0:
            self._length_cache[key] = runtime
        return runtime

    def _persist_length_if_needed(self, ep: Optional[Episode], length_seconds: float):
        if not ep or length_seconds <= 0:
            return
        existing = parse_float((ep.data or {}).get("length_seconds"))
        if abs(existing - length_seconds) < 0.5:
            return
        ep.data["length_seconds"] = length_seconds
        key = self._episode_cache_key(ep)
        self._length_cache[key] = length_seconds
        update_episode_metadata(
            ep.feed_name,
            ep,
            {"length_seconds": length_seconds},
        )

    def _serialize_queue(self) -> List[Dict[str, str]]:
        items: List[Dict[str, str]] = []
        for ep in self.queue:
            items.append(
                {
                    "feed": ep.feed_name,
                    "book": ep.book_name,
                    "tag": ep.tag,
                    "id": self._episode_identifier(ep),
                }
            )
        return items

    def _find_episode_ref(self, ref: Dict[str, str]) -> Optional[Episode]:
        if not isinstance(ref, dict):
            return None
        feed = ref.get("feed") or ""
        tag = ref.get("tag")
        item_id = _normalize_meta_key(ref.get("id") or "")
        book = ref.get("book") or ""
        if not item_id:
            return None

        def matches(ep: Episode) -> bool:
            ident = self._episode_identifier(ep)
            if ident == item_id:
                return True
            candidates = self._episode_lookup_keys(ep)
            return item_id in candidates

        if tag == "podcast":
            for ep in self.podcasts.get(feed, []):
                if matches(ep):
                    return ep
        elif tag == "book":
            for ep in self.books.get(feed, []):
                if book and safe_filename(ep.book_name) != safe_filename(book):
                    continue
                if matches(ep):
                    return ep
        # fallback search anywhere
        for eps in self.podcasts.values():
            for ep in eps:
                if matches(ep):
                    return ep
        for eps in self.books.values():
            for ep in eps:
                if matches(ep):
                    return ep
        return None

    def _set_position_with_retry(self, seconds: float, attempts: int = 5):
        # VLC sometimes ignores set_time until media is fully ready; retry briefly.
        if seconds <= 0:
            return

        def _apply(remaining: int):
            if remaining <= 0:
                return
            self.player.set_position(seconds)
            length = self.player.get_length()
            pos = self.player.get_position()
            if length <= 0 or pos < max(0.0, seconds - 0.5):
                self.after(200, lambda: _apply(remaining - 1))

        _apply(attempts)

    def _target_episode(self) -> Optional[Episode]:
        return self.playing_episode or self.current_episode

    def _on_player_end(self):
        # Called from VLC thread; bounce to the Tk loop.
        self._pending_end_event = True
        try:
            self.after(0, self._handle_player_end)
        except Exception:
            pass

    def _handle_player_end(self):
        if not self._pending_end_event:
            return
        self._pending_end_event = False
        if not self.playing_episode:
            return
        self.stop_playback(reached_end=True)

    def play_selected(self):
        mode = self.mode_var.get()
        if mode == "random":
            self.next_random()
            return
        if mode == "queue":
            ep = None
            # Resume paused item if we already pulled it from the queue.
            if self.playing_episode and not self.is_playing and not self.playing_episode.completed:
                ep = self.playing_episode
            elif self.queue:
                ep = self.queue.pop(0)
                self.current_episode = ep
                self._refresh_queue()
            if not ep:
                self.status_var.set("Queue is empty. Add items first.")
                return
        else:
            if not self.current_episode:
                self.status_var.set("Select an episode/chapter first.")
                return
            ep = self.current_episode
        path = self._resolve_episode_path(ep)
        if not path:
            messagebox.showerror("Audio", f"File not found for '{ep.title}'.")
            return
        if not self.player.load(path):
            return
        self.playing_episode = ep
        try:
            minutes = float(self.timer_var.get() or 0)
        except Exception:
            minutes = 0.0
        self.player.play()
        self._apply_speed()
        saved_pos = self._saved_position_from_disk(ep)
        start_pos = self.resume_position if self.resume_position is not None else ep.last_pos
        if start_pos <= 0 and saved_pos > 0:
            start_pos = saved_pos
            ep.data["last_position_seconds"] = saved_pos
        # Resume from cached position (pause or persisted metadata).
        self._set_position_with_retry(start_pos)
        self.player.start_timer(minutes, self._on_timer)
        self.status_var.set(f"Playing: {ep.title}")
        self._persist_run_state(mode, ep, start_pos)
        self._set_play_state(True)
        self.resume_position = None
        # Refresh colors to reflect current data state.
        self._refresh_episode_list()
        self._refresh_book_chapters()

    def _on_timer(self):
        self.stop_playback()
        messagebox.showinfo("Timer", "Listening timer elapsed.")

    def pause_playback(self):
        ep = self._target_episode()
        if ep:
            pos = self.player.get_position()
            update_episode_metadata(
                ep.feed_name,
                ep,
                {"last_listened_to": utc_now_iso(), "last_position_seconds": pos, "completed": False},
            )
            # Keep position cached so Play resumes from the paused spot.
            self.resume_position = pos
            ep.data["last_position_seconds"] = pos
            self._persist_run_state(self.mode_var.get(), ep, pos)
        self.player.pause()
        self.status_var.set("Paused")
        self._set_play_state(False)
        self._refresh_episode_list()
        self._refresh_book_chapters()

    def stop_playback(self, reached_end: bool = False):
        self.player.stop()
        ep = self._target_episode()
        if ep:
            pos = self.player.get_position()
            length = self._get_length_seconds(ep, self.player.get_length())
            completed = reached_end or (length > 0 and (length - pos) < 2.0)
            update_episode_metadata(
                ep.feed_name,
                ep,
                {
                    "last_listened_to": utc_now_iso(),
                    "last_position_seconds": 0 if completed else pos,
                    "completed": completed,
                },
            )
            # Persist position so next play resumes from here.
            self._persist_run_state(self.mode_var.get(), ep, 0 if completed else pos)
            # If completed, autoselect next item in the list (non-random modes).
            if completed:
                ep.data["completed"] = True
                ep.data["last_position_seconds"] = 0
            if completed:
                if self.mode_var.get() == "random":
                    self.next_random()
                else:
                    self._select_next_item()
        self.status_var.set("Stopped")
        self._set_play_state(False)
        self.playing_episode = None
        self._refresh_episode_list()
        self._refresh_book_chapters()
        if ep and ep.completed and self.mode_var.get() == "queue":
            self.current_episode = None
            self.after(100, lambda: self.play_selected() if self.queue else None)

    def next_random(self):
        # Choose a random eligible podcast episode according to toggle/filters.
        eligible = []
        for feed_name, eps in self.podcasts.items():
            if not self.random_enabled.get(feed_name, True):
                continue
            for ep in eps:
                if ep.completed or ep.data.get("archived"):
                    continue
                if ep.data.get("last_listened_to") and not self.include_partials_var.get():
                    continue
                eligible.append(ep)
        if not eligible:
            messagebox.showinfo("Random", "No eligible podcast episodes for Random mode.")
            return
        ep = random.choice(eligible)
        self.current_episode = ep
        self.mode_var.set("random")
        self.status_var.set(f"Random selected: {ep.title}")
        path = self._resolve_episode_path(ep)
        if not path:
            messagebox.showerror("Audio", f"File not found for '{ep.title}'.")
            return
        if not self.player.load(path):
            return
        try:
            minutes = float(self.timer_var.get() or 0)
        except Exception:
            minutes = 0.0
        self.player.play()
        saved_pos = self._saved_position_from_disk(ep)
        start_pos = saved_pos if saved_pos > 0 else 0
        if start_pos > 0:
            ep.data["last_position_seconds"] = start_pos
        self._set_position_with_retry(start_pos)
        self.player.start_timer(minutes, self._on_timer)
        self._persist_run_state("random", ep, 0)
        self._set_play_state(True)
        self.resume_position = None
        self.playing_episode = ep
        self._refresh_episode_list()
        self._refresh_book_chapters()

    def _persist_run_state(self, mode, episode: Optional[Episode], position: float):
        # Save current mode/selection/position for the next app launch.
        state: Dict = {"queue": self._serialize_queue()}
        if isinstance(mode, str):
            state["mode"] = mode
        if episode:
            state.update(
                {
                    "feed": episode.feed_name,
                    "book": episode.book_name,
                    "item_id": episode.enclosure_url or episode.local_file or episode.title,
                    "position": position,
                    "tag": episode.tag,
                }
            )
        save_run_state(state)

    def _load_run_state(self):
        # Restore last session's mode/selection and cached position.
        state = load_run_state()
        if not state:
            return
        mode = state.get("mode")
        self.mode_var.set(mode or "podcast")
        if mode == "podcast":
            feed = state.get("feed")
            if feed in self.podcasts:
                self.podcast_feed_var.set(feed)
                self._refresh_episode_list()
                # find by enclosure_url/local_file
                for idx, ep in enumerate(self.podcasts[feed]):
                    if ep.enclosure_url == state.get("item_id") or ep.local_file == state.get("item_id"):
                        self.current_episode = ep
                        self.resume_position = parse_float(state.get("position"))
                        if self.resume_position:
                            ep.data["last_position_seconds"] = self.resume_position
                        self.episode_list.selection_set(idx)
                        break
        elif mode == "book":
            book = state.get("book")
            if book:
                self.book_var.set(book)
                self._refresh_book_chapters()
                episodes = self.book_index.get(book, [])
                for idx, ep in enumerate(episodes):
                    if ep.enclosure_url == state.get("item_id") or ep.local_file == state.get("item_id"):
                        self.current_episode = ep
                        self.resume_position = parse_float(state.get("position"))
                        if self.resume_position:
                            ep.data["last_position_seconds"] = self.resume_position
                        self.chapter_list.selection_set(idx)
                        break
        # restore queue
        queue_refs = state.get("queue") or []
        restored: List[Episode] = []
        for ref in queue_refs:
            ep = self._find_episode_ref(ref)
            if ep and ep not in restored:
                restored.append(ep)
        self.queue = restored
        self._refresh_queue()
        # position is restored on play using resume_position

    def _get_current_list_and_index(self) -> Tuple[List[Episode], int, Optional[tk.Listbox]]:
        # Return the active list (podcasts or books), current index, and listbox widget.
        mode = self.mode_var.get()
        if mode == "podcast":
            feed_name = self.podcast_feed_var.get()
            episodes = self.filtered_podcast_episodes or list(self.podcasts.get(feed_name, []))
            idx = -1
            sel = self.episode_list.curselection()
            if sel:
                idx = sel[0]
            elif self.current_episode and self.current_episode in episodes:
                idx = episodes.index(self.current_episode)
            return episodes, idx, self.episode_list
        if mode == "book":
            book_name = self.book_var.get()
            episodes = self.filtered_book_chapters or list(self.book_index.get(book_name, []))
            idx = -1
            sel = self.chapter_list.curselection()
            if sel:
                idx = sel[0]
            elif self.current_episode and self.current_episode in episodes:
                idx = episodes.index(self.current_episode)
            return episodes, idx, self.chapter_list
        return [], -1, None

    def _on_close(self):
        # Save UI state
        state = {
            "geometry": self.geometry(),
            "mode": self.mode_var.get(),
            "podcast_feed": self.podcast_feed_var.get(),
            "book": self.book_var.get(),
            "speed": self.speed_var.get(),
        }
        save_json(Path(UI_STATE_FILE), state)
        self.destroy()

    def _select_next_item(self):
        mode = self.mode_var.get()
        if mode == "random":
            return
        episodes, idx, listbox = self._get_current_list_and_index()
        if idx == -1 or idx + 1 >= len(episodes):
            return
        next_ep = episodes[idx + 1]
        self.current_episode = next_ep
        if listbox:
            listbox.selection_clear(0, tk.END)
            listbox.selection_set(idx + 1)
            listbox.see(idx + 1)
        self._persist_run_state(mode, next_ep, next_ep.last_pos or 0)

    def _load_ui_state(self):
        # Restore window geometry and widget selections from the previous session.
        geom = self.ui_state.get("geometry")
        if geom:
            try:
                self.geometry(geom)
            except Exception:
                pass
        if self.ui_state.get("mode"):
            self.mode_var.set(self.ui_state.get("mode"))
        if self.ui_state.get("podcast_feed") in self.podcasts:
            self.podcast_feed_var.set(self.ui_state.get("podcast_feed"))
        if self.ui_state.get("book") in self.book_index:
            self.book_var.set(self.ui_state.get("book"))
        if self.ui_state.get("speed"):
            self.speed_var.set(self.ui_state.get("speed"))

    def _tick_ui(self):
        # Periodically update status with playback/selection info.
        status_text = "Ready"
        progress_text = self._current_selection_progress()
        timer_text = ""

        playing_ep = self.playing_episode if self.player.available else None
        player_pos = self.player.get_position() if playing_ep else 0.0
        player_len_runtime = self.player.get_length() if playing_ep else 0.0

        if playing_ep:
            length_sec = self._get_length_seconds(playing_ep, player_len_runtime)
            self._persist_length_if_needed(playing_ep, length_sec)
            self._auto_complete_if_near_end(playing_ep, player_pos, length_sec)
            status_text = f"Playing: {playing_ep.title} - {player_pos:.1f}s / {length_sec:.1f}s"
            progress_text = self._format_progress_text(playing_ep, player_pos, length_sec)
            if self.current_episode and self.current_episode is not playing_ep:
                saved_pos = parse_float(self.current_episode.data.get("last_position_seconds"))
                saved_len = self._get_length_seconds(self.current_episode, 0.0)
                progress_text += f" | Selected: {self.current_episode.title}"
                if saved_pos > 0 or saved_len > 0:
                    progress_text += f" ({saved_pos:.1f}s"
                    if saved_len > 0:
                        progress_text += f"/{saved_len:.1f}s"
                    progress_text += ")"
            if self.player.timer_end:
                remaining = max(0, self.player.timer_end - time.time())
                mins = int(remaining // 60)
                secs = int(remaining % 60)
                timer_text = f"Time left: {mins:02d}:{secs:02d}"
        elif self.current_episode:
            saved_pos = parse_float(self.current_episode.data.get("last_position_seconds"))
            length_sec = self._get_length_seconds(self.current_episode, 0.0)
            status_text = f"Selected: {self.current_episode.title}"
            if saved_pos > 0 or length_sec > 0:
                status_text += f" - saved {saved_pos:.1f}s"
                if length_sec > 0:
                    status_text += f"/{length_sec:.1f}s"
            progress_text = self._format_progress_text(self.current_episode, saved_pos, length_sec)

        self.status_var.set(status_text)
        self.progress_var.set(progress_text)
        self.timer_remaining_var.set(timer_text)
        self.after(500, self._tick_ui)

    def _current_selection_progress(self) -> str:
        # Display a simple completed/total summary for the active list.
        mode = self.mode_var.get()
        if mode == "podcast":
            feed = self.podcast_feed_var.get()
            eps = self.podcasts.get(feed, [])
        elif mode == "book":
            book = self.book_var.get()
            eps = self.book_index.get(book, [])
        else:
            return ""
        if not eps:
            return ""
        completed = sum(1 for e in eps if e.completed)
        return f"{completed}/{len(eps)} completed"

    def _format_progress_text(self, ep: Episode, pos: float, length: float) -> str:
        pct = 0.0
        if length > 0:
            pct = min(100.0, max(0.0, (pos / length) * 100))
        last_played = fmt_short(ep.data.get("last_listened_to"))
        first_played = fmt_short(ep.data.get("first_played"))
        info = f"Progress: {pct:.1f}%"
        if last_played:
            info += f" | Last: {last_played}"
        if first_played:
            info += f" | First: {first_played}"
        return info

    def _auto_complete_if_near_end(self, ep: Optional[Episode], pos: float, length: float):
        # If within the last 10 seconds of a track, mark it completed and persist.
        if not ep or length <= 0:
            return
        remaining = length - pos
        if remaining > 10:
            return
        if ep.completed:
            return
        update_episode_metadata(
            ep.feed_name,
            ep,
            {"last_listened_to": utc_now_iso(), "last_position_seconds": 0, "completed": True},
        )
        self._persist_run_state(self.mode_var.get(), ep, 0)
        ep.data["last_position_seconds"] = 0
        ep.data["completed"] = True
        self._refresh_episode_list()
        self._refresh_book_chapters()

    def skip_time(self, direction: int):
        # Jump forward/backward by the configured seconds value.
        try:
            delta = float(self.skip_var.get() or 0)
        except Exception:
            delta = 0
        delta *= direction
        ep = self._target_episode()
        if not ep:
            return
        current = self.player.get_position()
        new_pos = max(0.0, current + delta)
        self.player.set_position(new_pos)
        update_episode_metadata(ep.feed_name, ep, {"last_listened_to": utc_now_iso(), "last_position_seconds": new_pos, "completed": False})
        ep.data["last_position_seconds"] = new_pos
        self._persist_run_state(self.mode_var.get(), ep, new_pos)
        self._refresh_episode_list()
        self._refresh_book_chapters()
# last_position_seconds not last_position_seconds
    def mark_complete(self):
        ep = self._target_episode()
        if not ep:
            return
        update_episode_metadata(
            ep.feed_name,
            ep,
            {"last_listened_to": utc_now_iso(), "last_position_seconds": 0, "completed": True},
        )
        ep.data["last_position_seconds"] = 0
        ep.data["completed"] = True
        self._persist_run_state(self.mode_var.get(), ep, 0)
        self._refresh_episode_list()
        self._refresh_book_chapters()
        self._select_next_item()

    def _apply_speed(self):
        if not self.player.available or not self.player.player:
            return
        try:
            rate = float(self.speed_var.get() or 1.0)
        except Exception:
            rate = 1.0
        try:
            self.player.player.set_rate(rate)
        except Exception:
            pass

    def mark_archive(self):
        ep = self._target_episode()
        if not ep:
            return
        update_episode_metadata(
            ep.feed_name,
            ep,
            {"last_listened_to": utc_now_iso(), "archived": True},
        )
        ep.data["archived"] = True
        self._persist_run_state(self.mode_var.get(), ep, ep.last_pos or 0)
        self._refresh_episode_list()
        self._refresh_book_chapters()

    def add_bookmark(self):
        ep = self._target_episode()
        if not ep:
            return
        pos = self.player.get_position()
        bookmarks = list(ep.data.get("bookmarks") or [])
        bookmarks.append(pos)
        update_episode_metadata(
            ep.feed_name,
            ep,
            {"bookmarks": bookmarks, "last_listened_to": utc_now_iso(), "last_position_seconds": pos, "completed": False},
        )
        ep.data["bookmarks"] = bookmarks
        ep.data["last_position_seconds"] = pos
        self._persist_run_state(self.mode_var.get(), ep, pos)
        self._refresh_episode_list()
        self._refresh_book_chapters()

    def jump_last_bookmark(self):
        ep = self._target_episode()
        if not ep:
            return
        bookmarks = ep.data.get("bookmarks") or []
        if not bookmarks:
            return
        pos = float(bookmarks[-1])
        self.player.set_position(pos)
        update_episode_metadata(
            ep.feed_name,
            ep,
            {"last_listened_to": utc_now_iso(), "last_position_seconds": pos, "completed": False},
        )
        ep.data["last_position_seconds"] = pos
        self._persist_run_state(self.mode_var.get(), ep, pos)
        self._refresh_episode_list()
        self._refresh_book_chapters()

    # --- Settings handlers ----------------------------------------------------
    def _add_feed(self):
        dialog = FeedDialog(self, title="Add Feed")
        self.wait_window(dialog.top)
        if dialog.result:
            self.config_data.setdefault("feeds", []).append(dialog.result)
            self._save_config()

    def _edit_feed(self):
        sel = self.feed_tree.selection()
        if not sel:
            return
        name = sel[0]
        feed = next((f for f in self.config_data.get("feeds", []) if f.get("name") == name), None)
        if not feed:
            return
        dialog = FeedDialog(self, title="Edit Feed", feed=feed)
        self.wait_window(dialog.top)
        if dialog.result:
            feed.update(dialog.result)
            self._save_config()

    def _remove_feed(self):
        sel = self.feed_tree.selection()
        if not sel:
            return
        name = sel[0]
        self.config_data["feeds"] = [f for f in self.config_data.get("feeds", []) if f.get("name") != name]
        self._save_config()

    def _save_config(self):
        save_config(self.config_data)
        self.podcasts, self.books = load_library(self.config_data)
        self.random_enabled = load_random_enabled(self.config_data.get("feeds", []))
        self._refresh_lists()
        messagebox.showinfo("Config", "Saved config.yaml")

    def _toggle_random_selection(self):
        selections = self.random_list.curselection()
        podcasts = [f for f in self.config_data.get("feeds", []) if f.get("tag") == "podcast"]
        for idx in selections:
            if idx < len(podcasts):
                name = podcasts[idx].get("name")
                current = self.random_enabled.get(name, True)
                self.random_enabled[name] = not current
        save_random_enabled(self.random_enabled)
        self._refresh_lists()

    def _run_cleanup(self):
        # Attempt to run the external cleanup script and show its output.
        self.cleanup_output.delete("1.0", tk.END)
        try:
            proc = subprocess.run([sys.executable, "MyAutoLibrarianDel.py"], capture_output=True, text=True)
            output = proc.stdout + "\n" + proc.stderr
            self.cleanup_output.insert(tk.END, output)
        except Exception as exc:  # noqa: BLE001
            self.cleanup_output.insert(tk.END, f"Failed to run cleanup: {exc}")

    # --- Play/pause toggle ---------------------------------------------------
    def toggle_play_pause(self):
        if self.is_playing:
            self.pause_playback()
        else:
            self.play_selected()

    def _set_play_state(self, playing: bool):
        self.is_playing = playing
        try:
            self.play_pause_btn.config(text="Pause" if playing else "Play")
        except Exception:
            pass


# ---- Feed dialog -------------------------------------------------------------
class FeedDialog:
    def __init__(self, parent, title="Feed", feed=None):
        self.result = None
        top = self.top = tk.Toplevel(parent)
        top.title(title)
        top.transient(parent)
        top.grab_set()

        ttk.Label(top, text="Name").pack(fill=tk.X, padx=8, pady=4)
        self.name_var = tk.StringVar(value=(feed or {}).get("name", ""))
        ttk.Entry(top, textvariable=self.name_var).pack(fill=tk.X, padx=8)

        ttk.Label(top, text="URL").pack(fill=tk.X, padx=8, pady=4)
        self.url_var = tk.StringVar(value=(feed or {}).get("url", ""))
        ttk.Entry(top, textvariable=self.url_var).pack(fill=tk.X, padx=8)

        ttk.Label(top, text="Tag (podcast/book)").pack(fill=tk.X, padx=8, pady=4)
        self.tag_var = tk.StringVar(value=(feed or {}).get("tag", "podcast"))
        ttk.Entry(top, textvariable=self.tag_var).pack(fill=tk.X, padx=8)

        btns = ttk.Frame(top)
        btns.pack(pady=8)
        ttk.Button(btns, text="OK", command=self.ok).pack(side=tk.LEFT, padx=4)
        ttk.Button(btns, text="Cancel", command=self.cancel).pack(side=tk.LEFT, padx=4)

    def ok(self):
        name = self.name_var.get().strip()
        url = self.url_var.get().strip()
        tag = self.tag_var.get().strip().lower()
        if not name or not url or tag not in ("podcast", "book"):
            messagebox.showerror("Invalid", "Provide name, url, and tag (podcast/book).")
            return
        self.result = {"name": name, "url": url, "tag": tag}
        self.top.destroy()

    def cancel(self):
        self.top.destroy()


# ---- Main --------------------------------------------------------------------
def main():
    app = MyAutoLibrarianApp()
    app.protocol("WM_DELETE_WINDOW", app._on_close)
    app.mainloop()


if __name__ == "__main__":
    main()
