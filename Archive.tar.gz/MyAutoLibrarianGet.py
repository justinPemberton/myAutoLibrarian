#!/usr/bin/env python3
"""
MyAutoLibrarianGet: download new podcast episodes and audiobook chapters
based on feeds declared in config.yaml.
"""

from __future__ import annotations

import json
import os
import re
import sys
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from typing import Dict, Iterable, List, Optional, Tuple

CONFIG_FILE = "config.yaml"
PODCAST_FOLDER = "podcasts"
BOOK_FOLDER = "books"
EPISODES_FILENAME = "episodes.json"
DEFAULT_TIMEOUT = 30
AUDIO_EXTS = (".mp3", ".m4a", ".aac", ".wav", ".flac", ".ogg", ".oga", ".opus")
DEFAULT_HEADERS = {
    "User-Agent": "MyAutoLibrarian/1.0 (+https://example.local)",
}
SCRAPE_MAX_BYTES = 1_000_000  # cap HTML fetch for audio scraping
VERBOSE = False


def debug(msg: str) -> None:
    if VERBOSE:
        print(msg)


def scrape_audio_from_html(page_url: str) -> Optional[str]:
    """Fetch an HTML page and look for direct MP3 URLs."""
    try:
        req = urllib.request.Request(page_url, headers=DEFAULT_HEADERS)
        with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as resp:
            content_type = resp.headers.get("Content-Type", "")
            charset = "utf-8"
            match = re.search(r"charset=([\w-]+)", content_type)
            if match:
                charset = match.group(1)
            html_bytes = resp.read(SCRAPE_MAX_BYTES)
    except Exception as exc:  # noqa: BLE001
        debug(f"    Failed to fetch page for audio scrape: {exc}")
        return None

    try:
        html = html_bytes.decode(charset, errors="ignore")
    except Exception:
        html = html_bytes.decode("utf-8", errors="ignore")

    patterns = [
        r'"contentUrl"\s*:\s*"([^"]+\.mp3[^"]*)"',
        r'"audioUrl"\s*:\s*"([^"]+\.mp3[^"]*)"',
        r'"mp3"\s*:\s*"([^"]+\.mp3[^"]*)"',
        r"href=['\"]([^'\"]+\.mp3[^'\"]*)['\"]",
    ]
    for pat in patterns:
        match = re.search(pat, html, flags=re.IGNORECASE)
        if match:
            return match.group(1)

    fallback = re.search(r"(https?://[^\s\"'\\]+\.mp3[^\s\"'\\]*)", html, flags=re.IGNORECASE)
    if fallback:
        return fallback.group(1)
    return None


def safe_filename(name: str) -> str:
    cleaned = re.sub(r'[\\/*?:"<>|]', "", name)
    cleaned = re.sub(r"\s+", "_", cleaned).strip("._ ")
    return cleaned or "untitled"


def load_config(path: str = CONFIG_FILE) -> Optional[Dict]:
    try:
        import yaml  # type: ignore
    except ImportError:
        print("PyYAML is required to read config.yaml. Please install with `pip install pyyaml`.", file=sys.stderr)
        return None

    if not os.path.exists(path):
        print(f"Config file not found: {path}", file=sys.stderr)
        return None

    try:
        with open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except Exception as exc:  # noqa: BLE001
        print(f"Failed to read {path}: {exc}", file=sys.stderr)
        return None


def fetch_feed(url: str) -> Optional[bytes]:
    req = urllib.request.Request(url, headers=DEFAULT_HEADERS)
    try:
        debug(f"  Fetching feed: {url}")
        with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as response:
            return response.read()
    except Exception as exc:  # noqa: BLE001
        print(f"  Failed to fetch feed: {exc}")
        return None


def find_child(element: ET.Element, tag: str) -> Optional[ET.Element]:
    for child in element:
        if child.tag == tag or child.tag.endswith("}" + tag):
            return child
    return None


def get_child_text(element: ET.Element, tag: str) -> Optional[str]:
    node = find_child(element, tag)
    if node is not None and node.text:
        return node.text.strip()
    return None


def parse_pubdate(pubdate: Optional[str]) -> Optional[datetime]:
    if not pubdate:
        return None
    try:
        dt = parsedate_to_datetime(pubdate)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:  # noqa: BLE001
        return None


def infer_episode_number(title: str, item: ET.Element) -> Optional[int]:
    for child in item:
        tag_lower = child.tag.lower()
        if tag_lower.endswith("episode") or tag_lower.endswith("episode number") or tag_lower.endswith("episodenum"):
            try:
                return int(child.text.strip())
            except Exception:
                pass
    match = re.search(r"\d+", title)
    if match:
        try:
            return int(match.group(0))
        except Exception:
            return None
    return None


def is_probable_audio_url(url: Optional[str], type_hint: Optional[str] = None) -> bool:
    if not url:
        return False
    if type_hint and type_hint.lower().startswith("audio"):
        return True
    lower = url.lower()
    return any(lower.endswith(ext) for ext in AUDIO_EXTS)


def extract_enclosure_url(item: ET.Element, allow_link_fallback: bool = False) -> Tuple[Optional[str], Optional[str], bool, Optional[str]]:
    """
    Try to find an audio URL for this item. Prefer standard <enclosure> tags
    but also support common alternatives like Atom <link rel="enclosure"> and
    <media:content>.
    Returns (url, source_tag, is_audio, type_hint).
    """
    enclosure = find_child(item, "enclosure")
    if enclosure is not None:
        url = enclosure.get("url") or enclosure.get("href")
        type_hint = enclosure.get("type")
        if url:
            return url, "enclosure", is_probable_audio_url(url, type_hint), type_hint

    for child in item.iter():
        tag_lower = child.tag.lower()

        if tag_lower.endswith("link") and (child.get("rel") or "").lower() == "enclosure":
            candidate = child.get("href") or child.get("url")
            if not candidate and child.text:
                candidate = child.text.strip()
            type_hint = child.get("type")
            looks_audio = is_probable_audio_url(candidate, type_hint)
            if candidate and (looks_audio or allow_link_fallback):
                source = "link[rel=enclosure]" if looks_audio else "link-fallback"
                if allow_link_fallback and not looks_audio:
                    debug(f"    Fallback link (non-audio) candidate: {candidate}")
                return candidate, source, looks_audio, type_hint

        if "media" in tag_lower and tag_lower.endswith("content"):
            candidate = child.get("url") or child.get("href")
            if not candidate and child.text:
                candidate = child.text.strip()
            type_hint = child.get("type") or child.get("medium")
            looks_audio = is_probable_audio_url(candidate, type_hint)
            if candidate and (looks_audio or allow_link_fallback):
                source = "media:content" if looks_audio else "media:content-fallback"
                if allow_link_fallback and not looks_audio:
                    debug(f"    Fallback media:content (non-audio) candidate: {candidate}")
                return candidate, source, looks_audio, type_hint

    # As a last resort, accept link/guid fields if they look like direct audio files.
    link_text = get_child_text(item, "link")
    if link_text:
        looks_audio = is_probable_audio_url(link_text)
        if looks_audio or allow_link_fallback:
            source = "link" if looks_audio else "link-fallback"
            if allow_link_fallback and not looks_audio:
                debug(f"    Fallback <link> (non-audio) candidate: {link_text}")
            return link_text, source, looks_audio, None
    guid_text = get_child_text(item, "guid")
    if guid_text:
        looks_audio = is_probable_audio_url(guid_text)
        if looks_audio or allow_link_fallback:
            source = "guid" if looks_audio else "guid-fallback"
            if allow_link_fallback and not looks_audio:
                debug(f"    Fallback <guid> (non-audio) candidate: {guid_text}")
            return guid_text, source, looks_audio, None

    return None, None, False, None


def extract_feed_items(xml_bytes: bytes, allow_link_fallback: bool = False) -> List[Dict]:
    items: List[Dict] = []
    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError:
        return items

    channel = root.find("channel")
    if channel is None:
        channel = root.find(".//channel")
    if channel is None:
        return items

    for idx, item in enumerate(channel.findall("item")):
        title = get_child_text(item, "title") or f"Item {idx+1}"
        pub_raw = get_child_text(item, "pubDate")
        pub_dt = parse_pubdate(pub_raw)
        url, source_tag, is_audio, type_hint = extract_enclosure_url(item, allow_link_fallback=allow_link_fallback)
        episode_number = infer_episode_number(title, item)
        items.append(
            {
                "title": title,
                "pubDate": pub_raw,
                "pub_datetime": pub_dt,
                "url": url,
                "enclosure_source": source_tag,
                "enclosure_is_audio": is_audio,
                "enclosure_type": type_hint,
                "episode_number": episode_number,
                "index": idx,
            }
        )
    return items


def load_episodes(path: str) -> List[Dict]:
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                return data
    except Exception as exc:  # noqa: BLE001
        print(f"  Warning: could not read {path}: {exc}. Starting with empty list.")
    return []


def save_episodes(path: str, episodes: List[Dict]) -> None:
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(episodes, f, indent=2)
    except Exception as exc:  # noqa: BLE001
        print(f"  Failed to write {path}: {exc}")


def determine_extension(url: Optional[str], is_audio: Optional[bool] = None, type_hint: Optional[str] = None) -> str:
    if not url:
        return ".mp3" if is_audio is not False else ".html"
    parsed = urllib.parse.urlparse(url)
    ext = os.path.splitext(parsed.path)[1]
    if ext:
        return ext
    if is_audio is False:
        return ".html"
    if type_hint and type_hint.lower().startswith("audio"):
        return ".mp3"
    if is_probable_audio_url(url, type_hint):
        return ".mp3"
    if is_audio is True:
        return ".mp3"
    return ".mp3"


def build_filename(title: str, episode_number: Optional[int], url: Optional[str], pad: bool = False, is_audio: Optional[bool] = None, type_hint: Optional[str] = None) -> str:
    ext = determine_extension(url, is_audio=is_audio, type_hint=type_hint)
    base = safe_filename(title) or "episode"
    if episode_number is not None:
        number = str(episode_number).zfill(2 if pad else 1)
        return f"{number}-{base}{ext}"
    return f"{base}{ext}"


def episode_already_recorded(item: Dict, episodes: List[Dict]) -> bool:
    url = item.get("url")
    title = item.get("title")
    for episode in episodes:
        if url and episode.get("url") == url:
            return True
        if title and episode.get("title") == title:
            return True
    return False


def download_file(url: str, dest_path: str) -> bool:
    req = urllib.request.Request(url, headers=DEFAULT_HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as response, open(dest_path, "wb") as out:
            out.write(response.read())
        return True
    except Exception as exc:  # noqa: BLE001
        print(f"  Failed to download {url}: {exc}")
        return False


def newest_pubdate(episodes: List[Dict]) -> Optional[datetime]:
    newest: Optional[datetime] = None
    for ep in episodes:
        dt = parse_pubdate(ep.get("pubDate"))
        if dt is None:
            continue
        if newest is None or dt > newest:
            newest = dt
    return newest


def ensure_directory(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def reconcile_missing_entry(filename: str, item: Dict, episodes: List[Dict], dir_path: str) -> None:
    filepath = os.path.join(dir_path, filename)
    if os.path.exists(filepath) and not episode_already_recorded(item, episodes):
        entry = {
            "title": item.get("title"),
            "pubDate": item.get("pubDate"),
            "episode_number": item.get("episode_number"),
            "url": item.get("url"),
            "enclosure_source": item.get("enclosure_source"),
            "enclosure_is_audio": item.get("enclosure_is_audio"),
            "enclosure_type": item.get("enclosure_type"),
            "downloaded": datetime.now(timezone.utc).isoformat(),
        }
        episodes.append(entry)
        print(f"  Found existing file for '{entry['title']}', adding to episodes.json")


def process_podcast(feed: Dict, items: List[Dict], target_dir: str, episodes: List[Dict], allow_link_fallback: bool) -> None:
    ensure_directory(target_dir)
    newest_existing = newest_pubdate(episodes)
    to_download: List[Dict]
    debug(f"  Found {len(items)} items; newest existing pubdate: {newest_existing}")

    if not episodes:
        sorted_items = sorted(items, key=lambda x: x.get("pub_datetime") or datetime.min.replace(tzinfo=timezone.utc), reverse=True)
        to_download = sorted_items[:10]
    else:
        to_download = []
        for item in items:
            pub_dt: Optional[datetime] = item.get("pub_datetime")
            if newest_existing is None:
                if not episode_already_recorded(item, episodes):
                    to_download.append(item)
            elif pub_dt and pub_dt > newest_existing:
                to_download.append(item)

    debug(f"  Queued {len(to_download)} item(s) for download (podcast).")
    scrape_html_audio = bool(feed.get("scrape_page_audio", allow_link_fallback))
    new_entries = 0
    for item in to_download:
        url = item.get("url")
        scraped_audio = False
        if url and item.get("enclosure_is_audio") is False and scrape_html_audio:
            scraped = scrape_audio_from_html(url)
            if scraped:
                debug(f"    Found audio in page: {scraped}")
                url = scraped
                item["url"] = scraped
                item["enclosure_is_audio"] = True
                prev = item.get("enclosure_source") or "link-fallback"
                item["enclosure_source"] = f"{prev}+html-scrape"
                scraped_audio = True
        if not url:
            print(f"  Skipping '{item.get('title')}' (no playable enclosure URL found).")
            continue
        # If still not audio after scrape attempt, skip to avoid saving HTML.
        type_hint = item.get("enclosure_type")
        if (item.get("enclosure_is_audio") is False or not is_probable_audio_url(url, type_hint)) and not scraped_audio:
            print(f"  Skipping '{item.get('title')}' (no audio URL found on page).")
            continue
        filename = build_filename(
            item.get("title", "episode"),
            item.get("episode_number"),
            url,
            is_audio=item.get("enclosure_is_audio"),
            type_hint=item.get("enclosure_type"),
        )
        reconcile_missing_entry(filename, item, episodes, target_dir)
        filepath = os.path.join(target_dir, filename)
        if os.path.exists(filepath):
            print(f"  File already exists for '{item.get('title')}', skipping download.")
            continue
        if episode_already_recorded(item, episodes):
            print(f"  Episode '{item.get('title')}' already recorded, skipping.")
            continue
        source_note = ""
        if item.get("enclosure_source"):
            extra = "; non-audio fallback" if item.get("enclosure_is_audio") is False else ""
            source_note = f" (source: {item.get('enclosure_source')}{extra})"
        print(f"  Downloading '{item.get('title')}' -> {filename}{source_note}")
        if download_file(url, filepath):
            episodes.append(
                {
                    "title": item.get("title"),
                    "pubDate": item.get("pubDate"),
                    "episode_number": item.get("episode_number"),
                    "url": url,
                    "enclosure_source": item.get("enclosure_source"),
                    "enclosure_is_audio": item.get("enclosure_is_audio"),
                    "enclosure_type": item.get("enclosure_type"),
                    "downloaded": datetime.now(timezone.utc).isoformat(),
                }
            )
            new_entries += 1

    if new_entries == 0:
        print(f"  Sorry, we ran out.")
    else:
        print(f"  Added {new_entries} new episode(s).")


def audiobook_sort_key(item: Dict) -> Tuple[int, datetime, int]:
    chapter_num = item.get("episode_number")
    pub_dt = item.get("pub_datetime") or datetime.min.replace(tzinfo=timezone.utc)
    index = item.get("index", 0)
    use_num = chapter_num if chapter_num is not None else 10_000_000
    return (use_num, pub_dt, index)


def derive_book_folder_from_text(text: str) -> str:
    slug = safe_filename(text.replace(" ", "_"))
    slug = re.sub(r"^\d+-", "", slug)
    tokens = [tok for tok in slug.split("_") if tok]
    stop_prefixes = ("ch", "chapter")
    stop_words = {"fan", "audiobook"}
    name_tokens: List[str] = []
    for tok in tokens:
        low = tok.lower()
        if low.startswith(stop_prefixes) or low in stop_words:
            break
        name_tokens.append(tok)
    if not name_tokens:
        name_tokens = [slug or "book"]
    return "_".join(name_tokens)


def organize_existing_audiobook_files(target_dir: str) -> None:
    for entry in os.listdir(target_dir):
        if entry == EPISODES_FILENAME:
            continue
        current_path = os.path.join(target_dir, entry)
        if not os.path.isfile(current_path):
            continue
        folder = derive_book_folder_from_text(os.path.splitext(entry)[0])
        dest_dir = os.path.join(target_dir, folder)
        ensure_directory(dest_dir)
        dest_path = os.path.join(dest_dir, entry)
        if os.path.abspath(dest_path) == os.path.abspath(current_path):
            continue
        if os.path.exists(dest_path):
            # Avoid overwriting; leave in place if collision occurs.
            print(f"  Warning: destination exists for {entry}, leaving file in place.")
            continue
        os.rename(current_path, dest_path)


def process_audiobook(feed: Dict, items: List[Dict], target_dir: str, episodes: List[Dict]) -> None:
    ensure_directory(target_dir)
    organize_existing_audiobook_files(target_dir)
    existing_titles = {ep.get("title") for ep in episodes}
    existing_urls = {ep.get("url") for ep in episodes}
    sorted_items = sorted(items, key=audiobook_sort_key)
    debug(f"  Found {len(items)} items; queued {len(sorted_items)} item(s) for download (book).")

    new_entries = 0
    for item in sorted_items:
        title = item.get("title")
        url = item.get("url")
        if not url:
            print(f"  Skipping '{title}' (no playable enclosure URL found).")
            continue
        type_hint = item.get("enclosure_type")
        if item.get("enclosure_is_audio") is False or not is_probable_audio_url(url, type_hint):
            print(f"  Skipping '{title}' (no audio URL found).")
            continue
        if title in existing_titles or url in existing_urls:
            continue

        book_folder = derive_book_folder_from_text(title or "")
        book_dir = os.path.join(target_dir, book_folder)
        ensure_directory(book_dir)

        filename = build_filename(
            title or "chapter",
            item.get("episode_number"),
            url,
            pad=True,
            is_audio=item.get("enclosure_is_audio"),
            type_hint=item.get("enclosure_type"),
        )
        reconcile_missing_entry(filename, item, episodes, book_dir)
        filepath = os.path.join(book_dir, filename)
        if os.path.exists(filepath):
            print(f"  File already exists for '{title}', skipping download.")
            continue

        source_note = ""
        if item.get("enclosure_source"):
            extra = "; non-audio fallback" if item.get("enclosure_is_audio") is False else ""
            source_note = f" (source: {item.get('enclosure_source')}{extra})"
        print(f"  Downloading '{title}' -> {filename}{source_note}")
        if download_file(url, filepath):
            entry = {
                "title": title,
                "pubDate": item.get("pubDate"),
                "episode_number": item.get("episode_number"),
                "url": url,
                "enclosure_source": item.get("enclosure_source"),
                "enclosure_is_audio": item.get("enclosure_is_audio"),
                "enclosure_type": item.get("enclosure_type"),
                "book": book_folder,
                "downloaded": datetime.now(timezone.utc).isoformat(),
            }
            episodes.append(entry)
            existing_titles.add(title)
            existing_urls.add(url)
            new_entries += 1

    if new_entries == 0:
        print(f"  Sorry, we ran out.")
    else:
        print(f"  Added {new_entries} new chapter(s).")


def process_feed(feed: Dict) -> None:
    name = feed.get("name") or "Unknown Feed"
    url = feed.get("url")
    tag = (feed.get("tag") or "").lower()
    if not url:
        print(f"\nSkipping feed '{name}' (missing URL).")
        return

    base_dir = PODCAST_FOLDER if tag == "podcast" else BOOK_FOLDER if tag == "book" else None
    if base_dir is None:
        print(f"\nSkipping feed '{name}' (unknown tag '{tag}').")
        return

    print(f"\nProcessing feed: {name}")
    dir_path = os.path.join(base_dir, safe_filename(name))
    episodes_path = os.path.join(dir_path, EPISODES_FILENAME)
    episodes = load_episodes(episodes_path)

    xml_bytes = fetch_feed(url)
    if not xml_bytes:
        return

    allow_link_fallback = bool(
        feed.get("allow_no_enclosure")
        or feed.get("allow_link_fallback")
        or feed.get("allow_link_without_enclosure")
        or feed.get("fallback_to_link")
    )
    debug(f"  allow_link_fallback={allow_link_fallback}")
    items = extract_feed_items(xml_bytes, allow_link_fallback=allow_link_fallback)
    if not items:
        print("  No items found in feed.")
        return

    if tag == "podcast":
        process_podcast(feed, items, dir_path, episodes, allow_link_fallback=allow_link_fallback)
    else:
        process_audiobook(feed, items, dir_path, episodes)

    save_episodes(episodes_path, episodes)


def main(argv: Iterable[str]) -> int:
    global VERBOSE
    parsed_args: List[str] = []
    for arg in argv:
        if arg in ("-v", "--verbose"):
            VERBOSE = True
        else:
            parsed_args.append(arg)

    config = load_config()
    if not config or "feeds" not in config or not isinstance(config["feeds"], list):
        print("No feeds found in config.yaml.", file=sys.stderr)
        return 1

    for feed in config["feeds"]:
        if not isinstance(feed, dict):
            continue
        process_feed(feed)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
