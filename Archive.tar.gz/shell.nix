{ pkgs ? import <nixpkgs> {} }:
pkgs.mkShell {
  packages = [
    pkgs.libgcc
    pkgs.pkg-config

    pkgs.python3
    pkgs.python3Packages.pip
    pkgs.python3Packages.virtualenv
    pkgs.python3Packages.tkinter
    pkgs.python3Packages.pygame
    pkgs.python3Packages.pyyaml
    pkgs.python3Packages.python-vlc
  ];

  shellHook = ''
    if [ ! -d .venv ]; then
      python -m venv .venv
    fi
    source .venv/bin/activate

  '';
}
