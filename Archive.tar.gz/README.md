# MyAutoLibrarian

Local-first podcast/audiobook fetcher and player with a Tk GUI.

## Components
- `main.py`: entry point. `python main.py` runs downloader (`MyAutoLibrarianGet.py`), `python main.py run gui` launches the GUI (`MyAutoLibrarianRun.py`).
- `MyAutoLibrarianGet.py`: fetch feeds defined in `config.yaml`, download audio, and write `episodes.json` metadata per feed.
- `varifiy.py`: post-download verifier that checks each `episodes.json` entry, confirms the file exists, attempts to redownload missing files, and removes unrecoverable entries.
- `MyAutoLibrarianRun.py`: Tk-based player (uses VLC if available) that reads your local library and persists listening state.
- Data dirs: `podcasts/<feed>/` and `books/<feed>/`; each feed may have an `episodes.json` with metadata and resume info.
- State: `run_state.json` (last session), `ui_state.json` (window/layout preferences), `random_enabled.json` (random-mode toggles).

## Requirements
- Python 3.9+.
- `python-vlc` (and VLC installed) for audio playback; without it the GUI will show an error when trying to play.
- `pyyaml` for config parsing.
- Tkinter (usually bundled with Python on most platforms).

## Quick Start
1) Install deps (example):
   ```bash
   pip install python-vlc pyyaml
   ```
2) Add feeds to `config.yaml` (`name`, `url`, `tag` of `podcast` or `book`).
3) Download/update audio:
   ```bash
   python main.py        # add -v for verbose logs
   ```
   (This also runs `varifiy.py` afterward to ensure files exist; missing items are redownloaded when possible, otherwise removed from `episodes.json`.)
4) Launch the player GUI:
   ```bash
   python main.py run gui
   ```

## GUI Usage (MyAutoLibrarianRun)
- Modes: `Podcast`, `Book`, or `Random` (picks from enabled podcast feeds).
- Selecting: choose a feed/book from the dropdown, click an item in the list.
- Play/Pause:
  - On Play, the app checks `episodes.json` (and in-memory state) for `data.last_position_seconds` and seeks there so playback resumes seamlessly.
  - On Pause, it writes `last_position_seconds` into that episode’s `data` inside `episodes.json` so the next Play continues from the same timestamp.
- Timer: set minutes to auto-stop playback.
- Speed: choose playback rate (passed to VLC).
- Random: `Next Random` picks an eligible uncompleted/unarchived episode; `include partials` controls whether in-progress items are eligible.
- Completion/Archive: mark the current item complete or archived (affects coloring and random eligibility).
- Bookmarks: add a bookmark at the current time; jump to the last bookmark.
- Skip: enter seconds and use `+` / `-` buttons to jump forward/back.
- Settings tab:
  - Manage feeds (add/edit/remove, save back to `config.yaml`).
  - Toggle which podcast feeds are included in Random mode.
  - Run cleanup via `MyAutoLibrarianDel.py` (if present); output appears in the maintenance box.

## Feeds without enclosures
- If a feed item has no `<enclosure>` (e.g., some news RSS feeds), set `allow_no_enclosure: true` on that feed in `config.yaml`.
- With that flag, the downloader will fall back to the item `<link>`/`<guid>` even if it is not audio; files without an audio extension default to `.html`.

## File/Metadata Behavior
- `episodes.json` per feed stores an array of objects; each may have `data` containing:
  - `last_position_seconds`: saved on Pause or stop-without-complete; used to resume on the next Play.
  - `completed` / `archived` flags (also affect list coloring).
  - `bookmarks`: list of timestamp floats.
  - `last_listened_to` / `first_played`: timestamps in ISO format.
- For books, nested `episodes.json` files under a feed are merged so resume info is found regardless of subfolder.
- `run_state.json` keeps the last selected item/mode and resume position for the next app launch; `ui_state.json` saves window geometry and selections.

## Tips
- If playback always starts at 0, ensure `python-vlc` is installed and `episodes.json` is writable; check that `data.last_position_seconds` updates after pausing.
- Keep feed folder names stable; the app uses sanitized feed/book names to locate audio.
- Audio files can live directly under the feed folder or inside `audio/`; books may also use one folder per book title.
