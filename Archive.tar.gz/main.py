#!/usr/bin/env python3
"""Entry point for MyAutoLibrarian.

Usage:
  python main.py           # run downloader (MyAutoLibrarianGet)
  python main.py run gui   # launch GUI (MyAutoLibrarianRun)
  python main.py gui       # same as above
"""

import os
import sys
from pathlib import Path


def main() -> int:
    # Ensure we run relative to the script location so config.yaml is found.
    os.chdir(Path(__file__).resolve().parent)

    args = sys.argv[1:]
    if args and args[0].lower() in {"run", "gui"}:
        import MyAutoLibrarianRun

        MyAutoLibrarianRun.main()
        return 0

    import MyAutoLibrarianGet
    import varifiy

    get_result = MyAutoLibrarianGet.main(args)
    verify_result = varifiy.main([])
    return get_result or verify_result


if __name__ == "__main__":
    raise SystemExit(main())
